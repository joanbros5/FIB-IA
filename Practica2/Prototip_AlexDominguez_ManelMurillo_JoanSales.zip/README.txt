	
	--Prototip pràctica SBC--

1) Capacitats:

	> Generem un menú (esmorzar, dinar i sopar) per a tots els dies d'una setmana
	> Els menús són com a mínim aproximats a les calories necessàries de la persona
	> Contemplem un rang d'edat entre 65 i 105 anys (No deixa altre input d'edat)
	> Tenim aproximadament 80 instàncies de plats diferents
	> Assegurem que no es repeteixin plats díes seguits


2) Funcionament:

	Per a provar el codi, executar:

	> (load "pr2Classes.clp")
	> (load "pr2Functions.clp")
	> (load "pr2Instances.clp")
	> (load "pr2Moduls.clp")
	> (load "pr2Rules.clp")
	> (reset)
	> (run 1)
		Benvingut al increíble creador de menús!
	> (run 1)
		[input]
	> (run 1)
		[input]
	etc