Como ejecutar el programa:

1- Desde la terminal ir hasta /out/artifacts/practica_busqueda_jar/

2- Escribir en la terminal "java -jar practica_busqeda.jar"

3- Seguir las instrucciones que aparecen por la terminal