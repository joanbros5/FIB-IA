# practica_busqueda
Practica en IA en FIB
