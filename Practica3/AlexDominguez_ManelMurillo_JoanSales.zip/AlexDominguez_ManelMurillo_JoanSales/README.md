	
	- Base: Implementació base de la pràctica
		> jdp: jocs de proves trivial i impossible
		> Dominio.pddl: fitxer del domini del problema
                > Problem.pddl: un joc de proves genèric

	- ExX: Extensions de funcionalitats que es demanen de la pràctica
		Cadascuna té:
		> jdp: jocs de proves trivial i impossible
		> Dominio.pddl: fitxer del domini del problema
                > Problem.pddl: un joc de proves genèric

	**A Ex2 hi ha la carpeta experimentacio_temps que conté tots els
        jocs de proves utilitzats per fer la experimentació de l'Annex 2**

	- Generador_ExX: Codis i executables del generador de jocs de proves
	(Els executables només funcionen amb windows de 64 bits)